package com.example.tugas1_123230185

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
